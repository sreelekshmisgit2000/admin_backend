from django.db import models


# # Create your models here.

# class Hospital(models.Model):
#     # Step 1: Basic Info
#     name = models.CharField(max_length=255)
#     tagline = models.CharField(max_length=255, blank=True, null=True)
#     description = models.TextField(blank=True, null=True)
#     logo = models.ImageField(upload_to='hospital_logos/', blank=True, null=True)
#     cover_image = models.ImageField(upload_to='hospital_covers/', blank=True, null=True)
#     year_established = models.CharField(max_length=10, blank=True, null=True)
#     hospital_type = models.CharField(max_length=100, blank=True, null=True)
#     accreditation = models.JSONField(default=list, blank=True)
#     is_active = models.BooleanField(default=True)
#     license_number = models.CharField(max_length=100, blank=True, null=True)
#     registration_number = models.CharField(max_length=100, blank=True, null=True)
#     visiting_hours = models.CharField(max_length=255, blank=True, null=True)
#     operating_hours = models.CharField(max_length=255, blank=True, null=True)
#     insurance_accepted = models.TextField(blank=True, null=True)
#     languages_spoken = models.TextField(blank=True, null=True)
#     patient_capacity = models.CharField(max_length=50, blank=True, null=True)
#     hospital_features = models.TextField(blank=True, null=True)  # NEW: Hospital features as text
#     rating = models.CharField(max_length=10, blank=True, null=True)
#     reviews = models.TextField(blank=True, null=True)
#     facebook = models.URLField(blank=True, null=True)
#     twitter = models.URLField(blank=True, null=True)
#     instagram = models.URLField(blank=True, null=True)
#     parking_available = models.BooleanField(default=False)
#     parking_details = models.TextField(blank=True, null=True)
#     pharmacy_available = models.BooleanField(default=False)
#     blood_bank_available = models.BooleanField(default=False)
#     fax_number = models.CharField(max_length=20, blank=True, null=True)
    
#     # Step 2: Location & Contact
#     state = models.CharField(max_length=100, blank=True, null=True)
#     address = models.CharField(max_length=255)
#     city = models.CharField(max_length=100)
#     country = models.CharField(max_length=100)
#     nearby_landmarks = models.TextField(blank=True, null=True)
#     map_location = models.TextField(blank=True, null=True)
#     latitude = models.CharField(max_length=20, blank=True, null=True)
#     longitude = models.CharField(max_length=20, blank=True, null=True)
#     primary_contact_number = models.CharField(max_length=20, blank=True, null=True)
#     secondary_contact_number = models.CharField(max_length=20, blank=True, null=True)
#     phone = models.CharField(max_length=20)  
#     email = models.EmailField(max_length=255)
#     website = models.URLField(blank=True, null=True)
#     emergency_contact = models.CharField(max_length=20, blank=True, null=True)
#     ambulance_contact = models.CharField(max_length=20, blank=True, null=True)
     
#     owned_by = models.CharField(max_length=255, blank=True, null=True)
#     ceo_name = models.CharField(max_length=255, blank=True, null=True)
    

#     total_bed_count = models.CharField(max_length=10, blank=True, null=True)
#     icu_beds_available = models.BooleanField(default=False)
#     icu_beds_count = models.CharField(max_length=10, blank=True, null=True)
#     suite_rooms_available = models.BooleanField(default=False)
#     suite_rooms_count = models.CharField(max_length=10, blank=True, null=True)
#     suite_room_details = models.TextField(blank=True, null=True)
#     vip_rooms_available = models.BooleanField(default=False)
#     vip_rooms_count = models.CharField(max_length=10, blank=True, null=True)
#     vip_room_details = models.TextField(blank=True, null=True)
#     emergency_casualty_beds = models.CharField(max_length=10, blank=True, null=True)
    
   
#     specialties = models.JSONField(default=list, blank=True)
#     treatments = models.JSONField(default=list, blank=True)
#     allied_services = models.JSONField(default=list, blank=True)
    
    
#     seo_title = models.CharField(max_length=255, blank=True, null=True)
#     meta_description = models.TextField(blank=True, null=True)
#     keywords = models.TextField(blank=True, null=True)
#     slug = models.SlugField(max_length=255, blank=True, null=True, unique=True)
    
#     # Legacy fields for backward compatibility
#     type = models.CharField(max_length=100, blank=True, null=True)
#     status = models.CharField(max_length=20, default='Active')

#     def __str__(self):
#         return self.name

#     class Meta:
#         ordering = ['name']


# class Specialty(models.Model):
#     name = models.CharField(max_length=255, unique=True)
#     description = models.TextField(blank=True, null=True)
#     icon = models.CharField(max_length=100, blank=True, null=True)  # Icon class or identifier
#     is_active = models.BooleanField(default=True)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
    
#     def __str__(self):
#         return self.name
    
#     class Meta:
#         ordering = ['name']
#         verbose_name_plural = 'Specialties'


# class HospitalType(models.Model):
#     name = models.CharField(max_length=255, unique=True)
#     description = models.TextField(blank=True, null=True)
#     icon = models.CharField(max_length=100, blank=True, null=True)  # Icon class or identifier
#     is_active = models.BooleanField(default=True)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
    
#     def __str__(self):
#         return self.name
    
#     class Meta:
#         ordering = ['name']



class HospitalGallery(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to='hospital/gallery/')
    category = models.CharField(max_length=100, blank=True)  # eg: Operation Theatre, Reception, Labs
    is_featured = models.BooleanField(default=False)
    uploaded_by = models.CharField(max_length=100, blank=True)  # name of uploader/staff
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class HospitalAward(models.Model):
    title = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    award_date = models.DateField()
    awarded_by = models.CharField(max_length=150)
    award_type = models.CharField(max_length=100, blank=True)  # eg: National, State-level, International
    location = models.CharField(max_length=150, blank=True)    # where the award was given
    image = models.ImageField(upload_to='hospital/awards/', blank=True, null=True)
    certificate_file = models.FileField(upload_to='hospital/awards/certificates/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
